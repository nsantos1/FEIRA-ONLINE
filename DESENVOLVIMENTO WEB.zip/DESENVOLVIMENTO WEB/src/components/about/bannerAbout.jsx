export default function BannerAbout() {
  return (
    <div className="banner-about">
      <p>FeiraOnline</p>
      <h2>
        Conectando quem planta <br />
        com quem consome
      </h2>
    </div>
  );
}
