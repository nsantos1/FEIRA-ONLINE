export default function Banner() {
  return (
    <div className="blog-banner">
      <h2>Blog</h2>
      <p>As ultimas notícias de nossos produtores</p>
    </div>
  );
}
