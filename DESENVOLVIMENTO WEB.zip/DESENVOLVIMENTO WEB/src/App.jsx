import "./App.css";
import Rotas from "./rotas.jsx";


function App() {
  return (
    <Rotas />
  );
}

export default App;
